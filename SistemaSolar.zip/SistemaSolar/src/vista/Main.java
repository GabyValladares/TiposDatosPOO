
package vista;
import modelo.TipoPlaneta;
import modelo.Planeta;


/**
 *
 * @author Isak
 */
public class Main extends Planeta{
    private static String enano;
    private static String terrestre;
    private static String gaseoso;
    public static void main(String[] args) {
        
      
        // Crear instancias de Planeta
        System.out.println("PLANETA MERCURIO\n");
        Planeta mercurio = new Planeta("Mercurio", 0, 3.285E23, 6.083E10, 4879, 57, terrestre, false);
               

        Planeta jupiter = new Planeta("Jupiter", 79, 1.898E27, 1.42984E15, 142984, 778, gaseoso, false);
               System.out.println("PLANETA JUPITER\n");

        Planeta venus = new Planeta("Venus", 0, 4.867E24, 9.2843E11, 12104, 108, terrestre, false);
                System.out.println("PLANETA VENUS\n");

        Planeta tierra = new Planeta("Tierra", 1, 5.972E24, 1.08321E12, 12742, 149, terrestre, true);
                System.out.println("PLANETA TIERRA\n");

        Planeta marte = new Planeta("Marte", 2, 6.39E23, 1.6318E11, 6779, 228, terrestre, true);
                System.out.println("PLANETA MARTE\n");

        // Crear instancias de TipoPlaneta
        TipoPlaneta g = TipoPlaneta.GASEOSO;
        TipoPlaneta t = TipoPlaneta.TERRESTRE;
        TipoPlaneta e = TipoPlaneta.ENANO;

        // Imprimir los atributos de los planetas
   

        venus.imprimirAtributos();
           mercurio.imprimirAtributos();
        System.out.println("Densidad: " + mercurio.calcularDensidad() + " kg/km³\n");

        jupiter.imprimirAtributos();
        System.out.println("Densidad: " + jupiter.calcularDensidad() + " kg/km³");
  
        System.out.println("Densidad: " + venus.calcularDensidad() + " kg/km³\n");

        tierra.imprimirAtributos();
        System.out.println("Densidad: " + tierra.calcularDensidad() + " kg/km³\n");

        marte.imprimirAtributos();
        System.out.println("Densidad: " + marte.calcularDensidad() + " kg/km³\n");

    }

    public Main(String nombre, int cantidadSatelites, double masa, double volumen, int diametro, int distanciaMediaAlSol, String tipo, boolean observable) {
        super(nombre, cantidadSatelites, masa, volumen, diametro, distanciaMediaAlSol, tipo, observable);
    }
   // metodo para calcular la densidad
    public double calcularDensidad() {
        double masa = 0;
        double volumen = 0;
        return masa / volumen;
    }

    // Clase interna estática TipoPlaneta
    public static class TipoPlaneta {

        private static TipoPlaneta TERRESTRE;
        private static TipoPlaneta GASEOSO;
        private static TipoPlaneta ENANO;
        private String tipo;

        // Constructor de TipoPlaneta
        public TipoPlaneta(String tipo) {
            this.tipo = tipo;
        }

        // Método para obtener el tipo de planeta
        public String getTipo() {
            return tipo;
        }

        // Método para establecer el tipo de planeta
        public void setTipo(String tipo) {
            this.tipo = tipo;
        }
    }

    // Método para crear una instancia de TipoPlaneta

    public static TipoPlaneta crearTipoPlaneta(String tipo) {
        return new TipoPlaneta(tipo);
    }
}
