/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Isak
 */
import vista.Main;


public class TipoPlaneta {
    private String tipo;

    // Constructor
    public TipoPlaneta(String tipo) {
        this.tipo = tipo;
    }

    // Método para obtener el tipo de planeta
    public String getTipo() {
        return tipo;
    }

    // Método para establecer el tipo de planeta
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}
