/**
 *
 * @author Isak
 */

package modelo;

import vista.Main;
 
public class Planeta {
    private  String nombre;
    private int cantidadSatelites;
    private double masa; // en kilogramos
    private double volumen; // en kilómetros cúbicos
    private int diametro; // en kilómetros
    private int distanciaMediaAlSol; // en millones de kilómetros
    private String tipo; // Tipo de planeta (GASEOSO, TERRESTRE, ENANO, etc.)
    private boolean observable;

    // Constructor
    public Planeta(String nombre, int cantidadSatelites, double masa, double volumen, int diametro, int distanciaMediaAlSol, String tipo, boolean observable) {
        this.nombre = nombre;
        this.cantidadSatelites = cantidadSatelites;
        this.masa = masa;
        this.volumen = volumen;
        this.diametro = diametro;
        this.distanciaMediaAlSol = distanciaMediaAlSol;
        this.tipo = tipo;
        this.observable = observable;
    }

    

    

    // Método para imprimir los valores de los atributos de un planeta
    public void imprimirAtributos() {
              System.out.println("PLANETA MERCURIO\n");

        System.out.println("Nombre: " + nombre);
        System.out.println("Cantidad de satélites: " + cantidadSatelites);
        System.out.println("Masa: " + masa + " kg");
        System.out.println("Volumen: " + volumen + " km³");
        System.out.println("Diámetro: " + diametro + " km");
        System.out.println("Distancia media al Sol: " + distanciaMediaAlSol + " millones de km");
        System.out.println("Tipo de planeta: " + tipo);
        System.out.println("Observable a simple vista: " + (observable ? "Sí" : "No"));
    }

    // Método para calcular la densidad de un planeta
    public double calcularDensidad() {
        return masa / volumen;
    }

     static class TipoPlaneta {
        private String tipo;

        // Constructor
        public TipoPlaneta(String tipo) {
            this.tipo = tipo;
        }

        // Métodos para obtener y establecer el tipo de planeta
        public String getTipo() {
            return tipo;
        }

        public void setTipo(String tipo) {
            this.tipo = tipo;
        }
    }
}